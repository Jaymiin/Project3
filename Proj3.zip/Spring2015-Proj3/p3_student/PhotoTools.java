package p3_student;

import cmsc131PhotoLibrary.Photograph;
import cmsc131PhotoLibrary.Pixel;
import java.awt.color.*;

/**
 * This class will be written by the Student.  It provides various
 * static methods that take a photograph and produce a copy of it with
 * various modifications.
 * 
 * See the project description for details of method implementations.
 * 
 * @author Jasmine Yu
 * @TA Ahmed
 * @sec 0104
 * 3/26/2015
 *
 */
//int x will relate to getHt, int y will relate to getWd
public class PhotoTools {
	//makes a copy of the photo
	public static Photograph copy(Photograph photo) {
		Photograph theCopy = new Photograph(photo.getWd(), photo.getHt());
		for (int x = 0; x < photo.getHt(); x++){
			for (int y = 0; y < photo.getWd(); y++){
				//sets pixels back to where they were = copy
				theCopy.setPixel(y, x, photo.getPixel(y, x));
			}
		}
		return theCopy;
	}
	//makes the photo grayscale
	public static Photograph makeGrayscale(Photograph photo) {
		Photograph theCopy = new Photograph(photo.getWd(), photo.getHt());
		int Grayscale = 0;
		for (int x = 0; x < photo.getHt(); x++){
			for (int y = 0; y < photo.getWd(); y++){
				//add all colors together and divide by 3 avg = grey
				Grayscale = (photo.getPixel(y, x).getBlue() + photo.getPixel(y, x).getGreen() + photo.getPixel(y, x).getRed()) / 3;
				theCopy.setPixel(y, x, new Pixel(Grayscale, Grayscale, Grayscale));
				// defined int Grayscale = the mix
			}
		}
		return theCopy;
	}
	//puts black and white stripes over picture
	public static Photograph striped(Photograph photo) {
		Photograph theCopy = new Photograph(photo.getWd(), photo.getHt());
		for (int x = 0; x < photo.getHt(); x++){
			for (int y = 0; y < photo.getWd(); y++){
				//stripes of original picture
				if ((x / 10) % 3 == 0){ 
					theCopy.setPixel(y, x, photo.getPixel(y, x));
				} 
				//white stripe
				else if ((x /10) % 3 == 1) {
					theCopy.setPixel(y, x, new Pixel(255,255,255));
				}
				//black stripe
				else{ 
					theCopy.setPixel(y, x, new Pixel(0, 0, 0));
				}
			}
		}
		return theCopy;
	}
	// iolates color 
	public static Photograph isolateColor(Photograph photo, int type) {
		Photograph theCopy = new Photograph(photo.getWd(), photo.getHt());
		for (int x = 0; x < photo.getHt(); x++){
			for (int y = 0; y < photo.getWd(); y++){
				if (type == 0){ 
					theCopy.setPixel(y, x, new Pixel(photo.getPixel(y, x).getRed(), 0, 0));
				}
				else if (type == 1){ 
					theCopy.setPixel(y, x, new Pixel(0, photo.getPixel(y, x).getGreen(), 0));
				}
				else if (type == 2){ 
					theCopy.setPixel(y, x, new Pixel(0, 0, photo.getPixel(y, x).getBlue()));
				}
			}
		}
		return theCopy;
	}
	//stretches photo h/v
	public static Photograph stretched(Photograph photo, int type) {
		Photograph theCopy = null;
		if (type == 1){ 
			//ht stretch
			theCopy = new Photograph(photo.getWd(),photo.getHt() * 2);
			for (int y = 0; y < photo.getWd();y++){
				for (int x = 0; x < photo.getHt(); x++){
					theCopy.setPixel(y, x * 2, photo.getPixel(y, x));
					theCopy.setPixel(y, x * 2 + 1, photo.getPixel(y, x));
				}
			}
		} 
		//wd stretch
		else{ 
			theCopy = new Photograph(photo.getWd() * 2, photo.getHt());
			for (int x = 0; x < photo.getHt(); x++){
				for (int y = 0; y < photo.getWd(); y++){
					theCopy.setPixel(y * 2, x, photo.getPixel(y, x));
					theCopy.setPixel(y * 2 + 1, x, photo.getPixel(y,x));
				}
			}
		}
		return theCopy;
	}
	//flips photo horizontally
	public static Photograph mirrored(Photograph photo) {
		Photograph theCopy = new Photograph(photo.getWd(), photo.getHt());
		for (int y = 0; y < photo.getWd(); y++){
			for (int x = 0; x < photo.getHt(); x++){
				theCopy.setPixel(photo.getWd() - y - 1, x, photo.getPixel(y, x));
			}
		}
		return theCopy;
	}
	//rotates photo
	public static Photograph rotated(Photograph photo) {
		Photograph theCopy = new Photograph(photo.getHt(), photo.getWd());
		for (int y = 0; y < photo.getWd(); y++){
			for (int x = 0; x < photo.getHt(); x++){
				theCopy.setPixel(photo.getHt() - x - 1, y, photo.getPixel(y, x));
			}
		}
		return theCopy;
	}
	//turns photo upside down = double rotate
	public static Photograph upsideDown(Photograph photo) {
		return rotated(rotated(photo));
	}
	//sets three instances of the picture next to each other and sets color L>R red, green, blue
	public static Photograph weirdCombo(Photograph photo) {
		Photograph theCopy = null;
		//stretches width by 3
		theCopy = new Photograph(photo.getWd() * 3, photo.getHt()); 
		for (int x = 0; x < photo.getHt(); x++){
			for (int y = 0; y < photo.getWd()*3; y++){
				//splits photo into thirds
				if ( y /photo.getWd() % 3 == 0){ 
					//sets color of each copy
					theCopy.setPixel(y, x, new Pixel(photo.getPixel(y, x).getRed(), 0, 0));
					theCopy.setPixel(y + photo.getWd(), x, new Pixel(0, photo.getPixel(y, x).getGreen(), 0));
					theCopy.setPixel(y + (photo.getWd()*2), x, new Pixel(0,0, photo.getPixel(y, x).getBlue()));
				}
			}
		}
		return theCopy;
	}
}	